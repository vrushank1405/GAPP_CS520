package gapp.model;

public class ListDepartment {
	
	private int deptId;
	
	private String deptName;
	
	private int programCount;
	
	public ListDepartment(int deptId, String deptName, int programCount){
		this.deptId = deptId;
		this.deptName = deptName;
		this.programCount = programCount;
	}

	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public int getProgramCount() {
		return programCount;
	}

	public void setProgramCount(int programCount) {
		this.programCount = programCount;
	}

}
