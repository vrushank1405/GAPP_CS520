 alter table additional_info 
        drop constraint FK_6pib03m9h1jyq69p1gi3teed2;

    alter table additional_info 
        drop constraint FK_kmofexoi0pf1k2u8kmhtn0v1y;

    alter table additionalinfo_records 
        drop constraint FK_fku4obt05v4lg2j2jr3v7jb4t;

    alter table additionalinfo_records 
        drop constraint FK_i2y26vjmf0sv73o3pq43m0yc5;

    alter table additionalinfo_records 
        drop constraint FK_m19d35ygmeh04vucdvo8hyyhu;

    alter table applications 
        drop constraint FK_fvv8mt4q3l0jlgem0374rwfb5;

    alter table applications 
        drop constraint FK_bmuuaimvfefq39ypbc6y2itdu;

    alter table applications 
        drop constraint FK_11vghq2iaflf0eqtne7u9ooqa;

    alter table applications 
        drop constraint FK_il296b7i4a8es7mgs2a79gl8o;

    alter table applicationstatus_records 
        drop constraint FK_nh942nkxbk1utp3j8727o96hj;

    alter table applicationstatus_records 
        drop constraint FK_dxp621mkdtp4gau0kyse9esg2;
        
    alter table applicationstatus_records 
        drop constraint FK_hvyx3dvid4ksmih01817iv94b;

    alter table department_programs 
        drop constraint FK_icuahxx0w7yxj2cab3nisdmao;

        
    alter table education_info 
        drop constraint FK_oru6fl7f6p6bmnbey5xueo19n;

    alter table education_info 
        drop constraint FK_p6lapb5828l3uv4ggvxrivms6;

        
    alter table students_detail 
        drop constraint FK_sh587kyv2r3rs3m21l22tfjtp;

    alter table students_detail 
        drop constraint FK_aijkd0fr9o1fy56y27phqf24u;
        
        
drop table additional_info;

drop table additionalinfo_records;
drop table applications;
drop table applicationstatus_records;
drop table department_programs;
drop table departments	;
drop table education_info;
drop table program_terms;
drop table status;
drop table students_detail;
drop table users;

drop sequence hibernate_sequence;

