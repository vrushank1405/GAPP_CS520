package gapp.model.dao;

import gapp.model.Status;

import java.util.List;

public interface StatusDao {
	
	Status getStatus( Integer id );

    List<Status> getStatus();
}
