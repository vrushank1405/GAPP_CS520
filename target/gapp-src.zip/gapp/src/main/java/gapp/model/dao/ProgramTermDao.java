package gapp.model.dao;

import gapp.model.DepartmentProgram;
import gapp.model.ProgramTerm;

import java.util.List;

public interface ProgramTermDao {
	
	List<ProgramTerm> getProgramTerm();
	
	ProgramTerm getProgramTerm(Integer id);

}
